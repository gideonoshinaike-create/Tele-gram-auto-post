'use client';
import { useState } from 'react';

type Post = { id: number; text: string; when: string; status: 'Draft' | 'Scheduled' };
export default function Home() {
  const [tab, setTab] = useState('Dashboard');
  const [message, setMessage] = useState('');
  const [posts, setPosts] = useState<Post[]>([
    { id: 1, text: 'Welcome! Your Telegram Auto Post workspace is ready.', when: 'Demo item', status: 'Draft' },
    { id: 2, text: 'Your scheduled posts will appear here.', when: 'Demo item', status: 'Scheduled' }
  ]);
  const [light, setLight] = useState(false);
  function saveDraft() {
    if (!message.trim()) return;
    setPosts([{ id: Date.now(), text: message.trim(), when: 'Just now', status: 'Draft' }, ...posts]);
    setMessage('');
    setTab('Scheduled Posts');
  }
  const nav = ['Dashboard', 'Channels', 'Create Post', 'Scheduled Posts', 'Posting History', 'Settings'];
  return (
    <main className={light ? 'app light' : 'app'}>
      <header className="topbar">
        <div className="brand"><span className="brandIcon">✈</span><span>TELEGRAM <b>AUTO POST</b></span></div>
        <button className="theme" onClick={() => setLight(!light)} aria-label="Toggle theme">{light ? '☾' : '☀'}</button>
      </header>
      <div className="shell">
        <aside className="sidebar">
          <p className="eyebrow">WORKSPACE</p>
          {nav.map(item => <button key={item} className={tab === item ? 'nav active' : 'nav'} onClick={() => setTab(item)}>{item === 'Dashboard' ? '▦' : item === 'Channels' ? '◉' : item === 'Create Post' ? '＋' : item === 'Scheduled Posts' ? '◷' : item === 'Posting History' ? '↺' : '⚙'} <span>{item}</span></button>)}
          <div className="sideNote"><span className="dot"/> Mobile workspace</div>
        </aside>
        <section className="content">
          <div className="welcome"><div><p className="eyebrow">YOUR PUBLISHING WORKSPACE</p><h1>{tab === 'Dashboard' ? 'Dashboard' : tab}</h1><p className="muted">Plan and manage your Telegram channel content in one place.</p></div><span className="avatar">TA</span></div>
          {tab === 'Dashboard' && <>
            <div className="stats">
              <div className="stat"><span>Connected channels</span><strong>0</strong><small>Connect a bot to begin</small></div>
              <div className="stat"><span>Scheduled posts</span><strong>{posts.filter(p => p.status === 'Scheduled').length}</strong><small>Demo workspace data</small></div>
              <div className="stat"><span>Published posts</span><strong>0</strong><small>Not connected yet</small></div>
            </div>
            <div className="panel"><div className="panelHead"><div><h2>Quick start</h2><p className="muted">Your next steps</p></div><span className="tag">SETUP</span></div>
              <div className="steps"><div><i>1</i><span><b>Connect a Telegram channel</b><small>Add your Telegram bot as a channel administrator.</small></span></div><div><i>2</i><span><b>Create your first post</b><small>Write a message and save it as a draft.</small></span></div><div><i>3</i><span><b>Schedule publishing</b><small>Scheduling will be enabled after the backend is connected.</small></span></div></div>
            </div>
          </>}
          {tab === 'Create Post' && <div className="panel"><h2>Create a post</h2><p className="muted">Write a draft for your Telegram channel.</p><label htmlFor="post">Post text</label><textarea id="post" value={message} onChange={e => setMessage(e.target.value)} placeholder="Write your Telegram post here..." rows={7}/><div className="actions"><span className="muted">{message.length} characters</span><button className="primary" onClick={saveDraft}>Save draft</button></div><p className="hint">Draft saving is currently local demo functionality. It does not publish to Telegram.</p></div>}
          {tab === 'Channels' && <div className="panel empty"><div className="emptyIcon">◉</div><h2>No channels connected</h2><p className="muted">The secure Telegram connection step will be added next.</p><p className="hint">Never paste your bot token into this demo page.</p></div>}
          {(tab === 'Scheduled Posts' || tab === 'Posting History') && <div className="panel"><div className="panelHead"><div><h2>{tab}</h2><p className="muted">Your content list</p></div></div>{posts.map(p => <article className="post" key={p.id}><div className="postTop"><span className="tag">{p.status}</span><small>{p.when}</small></div><p>{p.text}</p></article>)}</div>}
          {tab === 'Settings' && <div className="panel"><h2>Settings</h2><p className="muted">Choose the appearance of your workspace.</p><button className="secondary" onClick={() => setLight(!light)}>Switch to {light ? 'dark' : 'light'} theme</button><p className="hint">Account login, secure token storage and database settings will be added in a later stage.</p></div>}
          <footer>TELEGRAM AUTO POST <span>•</span> Mobile-first workspace</footer>
        </section>
      </div>
    </main>
  );
}

# TELEGRAM AUTO POST

Mobile-first Next.js starter for an Android-friendly web app.

## Run locally
1. Install Node.js 20 or later.
2. Run `npm install`.
3. Run `npm run dev`.
4. Open the local address shown in the terminal.

## Current status
This is a frontend starter. The dashboard and local draft demo work, but Telegram connection, secure authentication, database storage, server-side scheduling, and real publishing are not implemented yet.

Do not enter Telegram bot tokens into this frontend. They must only be handled by a secure server-side backend over HTTPS.
